let hit_buffer = null,hit_audioCtx = null;

(async() => {
    hit_audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const res = await fetch('sound/hit.wav');
    const arrayBuffer = await res.arrayBuffer();
    hit_buffer = await hit_audioCtx.decodeAudioData(arrayBuffer);
})()
    
let drag_buffer = null,drag_audioCtx = null;
(async() => {
    drag_audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const res = await fetch('sound/drag.wav');
    const arrayBuffer = await res.arrayBuffer();
    drag_buffer = await drag_audioCtx.decodeAudioData(arrayBuffer);
})()

let flick_buffer = null,flick_audioCtx = null;
(async() => {
    flick_audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const res = await fetch('sound/hit.wav');
    const arrayBuffer = await res.arrayBuffer();
    flick_buffer = await flick_audioCtx.decodeAudioData(arrayBuffer);
})()

async function hitsoundplay(gain,delay){
    let offset = audio_offset.value || 0
    if (hit_audioCtx.state === 'suspended') hit_audioCtx.resume();
    const hit = hit_audioCtx.createBufferSource();
    const hit_volume = hit_audioCtx.createGain();
    hit_volume.gain.value = 1 + Math.sqrt(gain-1)*0.6;
    hit.buffer = hit_buffer;
    hit.connect(hit_volume); 
    hit_volume.connect(hit_audioCtx.destination);
    hit.start(hit_audioCtx.currentTime + delay + offset/1000,0.16);
}

async function dragsoundplay(delay){
    let offset = audio_offset.value || 0
    const drag = drag_audioCtx.createBufferSource();
    const drag_volume = drag_audioCtx.createGain();
    drag_volume.gain.value = 0.6;
    drag.buffer = drag_buffer;
    drag_volume.connect(drag_audioCtx.destination)
    drag.connect(drag_volume);
    drag.start(drag_audioCtx.currentTime + delay + offset/1000,0.22)
}
