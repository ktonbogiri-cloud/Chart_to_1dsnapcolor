function chartextract(chart){
    if(chart != null && chart != 0){
        console.log(chart);
        
        
        chartname = localStorage.getItem("filename") || null
        beat = parseInt(localStorage.getItem("beat")) || 1

        readchart(beat);
        chartlength = Object.keys(chart).length - 2;
        document.getElementById("chartname").textContent = JSON.stringify(chartname.replace(/\.[^.]+$/, "").replace(/\.[^.]+$/, ""));
        
        timelist_update()
        tip_info()
    }else{
        tip.innerHTML = "无缓存文件，请上传"
    }
}

function timelist_update(){
    let part_time = 0
    for(b = 1 ; b <= chartlength; b++){
        timelist.push(part_time)
        part_time += part_time_span(chart[b])
    }
}

async function chartload() {
    let chartfile = document.getElementById("chartfilename").value
    chartname = "热修改文件"
    const res = await fetch(`${chartfile}.json`);
    chart = await res.json();
    chartlength = Object.keys(chart).length - 2;
    chart_refresh(beat)
    timelist_update()
    tip_info()
}

async function videoload() {
    let videofilename = document.getElementById("videofilename").value
    localStorage.setItem("videofilename",videofilename)
    videoshow(videofilename)
    tip.innerHTML = "视频已加载"
}

document.getElementById("chartfileurl").onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    chartname = file.name
    localStorage.setItem("filename",chartname)
    const reader = new FileReader();

    reader.onload = (ev) => {
        chart = JSON.parse(ev.target.result);
        localStorage.setItem("chart", JSON.stringify(chart));
        chartextract(chart)
    };
    reader.readAsText(file);
};

let file = null;
document.getElementById("videourl").onchange = (e) => {
    file = e.target.files[0];
    if (!file) return;
    videoname = file.name
    document.getElementById("videoname").innerHTML = videoname
    tip.innerHTML = `已加载视频文件${videoname}`

    const videourl = URL.createObjectURL(file);
    videoshow(videourl)
};

function videoshow(videourl){
    video.src = videourl;
    videoview.style.display = "block"

    state.video = true
    state.videodiaplsy = false
    videodisplay(document.getElementById("videoshow"))
}