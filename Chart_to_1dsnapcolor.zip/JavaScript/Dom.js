const
bpmtext = document.getElementById("BPM")
bpmbg = document.getElementById("BPMbg")
pos = document.getElementById("pos")

rectbody = document.getElementById("mainbg")
bodybg = document.getElementById("currentbg")
cbg = document.getElementById("cbg")

tip = document.getElementById("tip")
chartplaywindow = document.getElementById("chartplaywindow")

combo = document.getElementById("combo")
combobg = document.getElementById("combobg")
beats_tempbg = document.getElementById("beats_tempbg")

star = document.getElementById("star")
csbg = document.getElementById("csbg")

cs = document.getElementById("chart")
border = document.getElementById("border")
jumpto = document.getElementById("jumpto")

hotmode = document.getElementById("hotmode")
hot_switch = document.getElementById("hotmode_switch")

mainbgheightslider = document.getElementById("mainbgheightslider")

video = document.getElementById("video")
videosizeslider = document.getElementById("videosizeslider")
videosize = document.getElementById("videosize")
video_panel = document.getElementById("video_panel")
videoview = document.getElementById("videoview")
video_offset = document.getElementById("video_offset")
videofilename = document.getElementById("videofilename")
videofilename.value = localStorage.getItem("videofilename") || ""

audio_on = document.getElementById("audio_on")
audio_offset = document.getElementById("audio_offset")

originchart = document.getElementById("originchart")
originchart.value = localStorage.getItem("origincharturl") || ""

charttype = document.getElementById("charttype")
charttype.value = localStorage.getItem("charttype") || "J"

bpmlistorigin = {1:[123,4,4,"4/4"]}
bpmlist = document.getElementById("bpmlist")
bpmlist.value = localStorage.getItem("bpmlist") || JSON.stringify(bpmlistorigin)

chartoffset = document.getElementById("chartoffset")
chartoffset.value = localStorage.getItem("chartoffset") || 0

maimaidif = document.getElementById("MAIMAIDIF")
maimaidiftext = document.getElementById("MAIMAIDIFTEXT")
maimaidif.value = localStorage.getItem("maimaidif") || 1
