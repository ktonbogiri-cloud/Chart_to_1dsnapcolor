let keyPressed = false;

document.onkeydown = (event) => {
    if (document.activeElement.classList.contains("input")) return;
    if(event.key == " "){
        event.preventDefault();
        pause_pressd(pause)
    }else if(event.key == "ArrowLeft"){
        event.preventDefault();
        pagejump(-1)
    }else if(event.key == "ArrowRight"){
        event.preventDefault();
        pagejump(1)
    }else if(event.key == ";"){
        event.preventDefault();
        settingwindowopen()
    }else if(event.key == "v" && !event.ctrlKey){
        videoplay()
    }else if(event.key === "f") {
        document.getElementById("chartplaywindow").requestFullscreen();
    }else if(event.key === "j") {
        chartshowopen();
    }else if(event.key === "g") {
        if(!state.setting_window || !state.setting_window2 || !state.panelwindow){
            state.window_all = true
        }else{
            state.window_all = false
        }

        if(state.window_all){
            if(!state.setting_window){settingwindowopen()}
            if(!state.setting_window2){settingwindow2open()}
            if(!state.panelwindow){panelwindowopen()}
        }else{
            panelwindowopen()
            settingwindowopen()
            settingwindow2open()
        }
    }
    keyPressed = true
};

document.addEventListener("keyup", () => {
    keyPressed = false;
});

document.addEventListener("wheel", (e) => {
    if(keyPressed){
        return
    }else if(e.deltaY > 0){
        pagejump(1)
    }else{
        pagejump(-1)
    }
});



function button_on(b,text="",bg_color="#02de98",text_color="#000000"){
    b.style.background = bg_color
    b.style.color = text_color
    b.innerHTML = text
}
function button_off(b,text="",bg_color="#5a5a5a",text_color="#ffffff"){
    b.style.background = bg_color
    b.style.color = text_color
    b.innerHTML = text
}

function button_switch(state,b,text_off="",text_on=""){
    let x = 0;
    if(state){
        button_off(b,text_off)
        x = -60
    }else{
        button_on(b,text_on)
    }
    return [!state,x]
}

function button_switch2(state,b,text_off="",text_on=""){
    if(state){
        button_off(b,text_off,"#222222")
    }else{
        button_on(b,text_on)
    }
    return !state
}


if(mode == "hotmode"){
    videoload()
    chartload()
    button_on(hot_switch,"开")
    hotmode.style.height = 120 + "px"
    hotmode.style.opacity = 1
    state.hotmode = true
}else{
    chart = JSON.parse(chart)
    chartextract(chart)
}

function hotmode_switch(b){
    state.hotmode = button_switch2(state.hotmode,b,text_off="关",text_on="开")
    if(state.hotmode){
        hotmode.style.height = 120 + "px"
        hotmode.style.opacity = 1
        chartload()
        localStorage.setItem("mode","hotmode")
    }else{
        hotmode.style.height = 0 + "px"
        hotmode.style.opacity = 0
        chart = localStorage.getItem("chart") || null
        chart = JSON.parse(chart)
        chartextract(chart)
        localStorage.setItem("mode","null")
    }
}

if(approximate_mode == 1){
    approximate_switch(document.getElementById("approximate_switch"))
}
function approximate_switch(b){
    state.approximate = button_switch2(state.approximate,b,text_off="关",text_on="开")
    if(state.approximate){
        approximate_mode = 1
    }else{
        approximate_mode = 0
    }
    localStorage.setItem("approximate",approximate_mode)
}

function videodisplay(b){
    state.videodiaplsy = button_switch2(state.videodiaplsy,b,"视频关","视频开")
    if(state.videodiaplsy){
        state.video = true
        videoview.style.display = "block" 
    }else{
        state.video = false
        videoview.style.display = "none" 
        video.pause()
    }
}

function videoplay(){
    if(!state.videoplay){
        video.play()
    }else{
        video.pause()
    }
    state.videoplay = !state.videoplay
}

function videosync(){
    let offset = localStorage.getItem("video_offset") || 0
    let ct = 0
    if(timelist.length != 0){
        ct = timelist[beat]
    }
    ct = ct + offset/1000 - 2

    if(ct < 0){ct = 0}
    video.currentTime = ct;
    
    if(running && state.video){video.play()}
}

function pause_pressd(b){
    if (!state.paused) {
        video.pause()
        if(current_page >= chartlength + 1){
            pagejump(1-beat)
        }
        button_off(b,"继续","#222222","#ffffff")
        running = false;
    } else {
        running = true;
        if(state.videodiaplsy){
            videosync()
        }
        chart_refresh(beat)
        button_on(b,"播放中","#02de98","#000000")
        nx = startx
        prevtime = Date.now()
        chart_refresh(beat)
        requestAnimationFrame(start);
    }
    state.paused = !state.paused
    localStorage.setItem("beat",beat)
}

function chartapply(){
    chartname = document.getElementById("chartfileurl").value
    tip.innerText = `已切换谱面${chartname}`
    localStorage.setItem("chartname",`outputcharts/${chartname}.json`)
    charturl = `outputcharts/${chartname}.json`
    loadchart(charturl)
    chart_refresh(beat)
    pagejump(0)
}

function bgapply(){
    bgname = document.getElementById("bgfileurl").value;
    localStorage.setItem("bgname",`bg/${bgname}.png`)
    chartplaywindow.style.setProperty("--bgimage", `url('bg/${bgname}.png')`);
}

function audiooffsetapply(){
    if(audio_offset.value < 0){
        audio_offset.value = 0
        tip.innerHTML = "此偏移值不可低于0"
    }
    localStorage.setItem("audio_offset",audio_offset.value);
}

function audiooffsetplus(){
    audio_offset.value = parseInt(audio_offset.value) + 10
    audiooffsetapply()
}

function audiooffsetred(){
    audio_offset.value = parseInt(audio_offset.value) - 10
    audiooffsetapply()
}

function audiooffsetreset(){
    audio_offset.value = 0
    audiooffsetapply()
}

audio_offset.onchange = () =>{
    audiooffsetapply()
}

function audio_on_off(b){
    state.audio_on = button_switch2(state.audio_on,b,"打击关","打击开") 
}

function videooffsetapply(){
    localStorage.setItem("video_offset",video_offset.value);
}

function videooffsetplus(){
    video_offset.value = parseInt(video_offset.value) + 10
    videooffsetapply()
}

function videooffsetred(){
    video_offset.value = parseInt(video_offset.value) - 10
    videooffsetapply()
}

function videooffsetreset(){
    video_offset.value = 0
    videooffsetapply()
}

function videovolumereset(){
    audiosizeslider.value = 100
    video.volume = 1
}

function videosizereset(){
    videosizeslider.value = 60
    video.style.height = 60 + "vh"
}

video_offset.onchange = () =>{
    videooffsetapply()
}

function chartshowopen(){
    const chartshow = document.getElementById("chartshow");
    if(state.jubeat_window){
        chartshow.classList.toggle("open");
        document.getElementById("jubeat_fold").style.transform = "rotateX(180deg) translateX(-50%)"
        for(let i=0;i<=15;i++){
            cs.innerHTML += `<div id="note${i}" style="position:absolute;width:120px;height: 120px;left:${i%4*130+400}px;top:${Math.floor(i/4)*130+50}px;
            background:#111111;user-select: none;border-radius: 4px;font-size: 58px;display:grid;place-items: center;text-shadow: 3px 3px 3px #000000;"></div>`
            csbg.innerHTML = ""
        }
    }else{
        chartshow.classList.toggle("open",false);
        document.getElementById("jubeat_fold").style.transform = "rotateX(0deg) translateX(-50%)"
        cs.innerHTML = ""
    }
    state.jubeat_window = !state.jubeat_window
}

function settingwindowopen(){
    const sw = document.getElementById("settingwindow");
    if(state.setting_window){
        sw.style.opacity = 1
        sw.style.height = "auto"
        document.getElementById("setting_fold").style.transform = "rotateX(180deg)"
    }else{
        sw.style.opacity = 0
        sw.style.height = "0px"
        document.getElementById("setting_fold").style.transform = "rotateX(0deg)"
    }
    state.setting_window = !state.setting_window
}

function settingwindow2open(){
    const sw = document.getElementById("settingwindow2");
    if(state.setting_window2){
        sw.style.opacity = 1
        sw.style.height = "240px"
        if(state.hotmode){hotmode.style.opacity = 1}
        hotmode.style.height = "120px"
        document.getElementById("setting_fold2").style.transform = "rotateX(0deg)"
    }else{
        sw.style.opacity = 0
        sw.style.height = "0px"
        hotmode.style.opacity = 0
        hotmode.style.height = "0px"
        document.getElementById("setting_fold2").style.transform = "rotateX(180deg)"
    }
    state.setting_window2 = !state.setting_window2
}

function panelwindowopen(){
    const sw = document.getElementById("panelwindow");
    if(state.panelwindow){
        sw.style.opacity = 1
        sw.style.bottom = "10px"
        document.getElementById("panel_fold").style.transform += "rotateX(180deg)"
    }else{
        sw.style.opacity = 0
        sw.style.bottom = "-100px"
        document.getElementById("panel_fold").style.transform += "rotateX(180deg)"
    }
    state.panelwindow = !state.panelwindow
}

function dargshow_switch(b){
    state.dragshow = button_switch2(state.dragshow,b,"D","D")
    chart_refresh(beat)
}

function flickshow_switch(b){
    state.flickshow = button_switch2(state.flickshow,b,"F","F")
    chart_refresh(beat)
}

function beatcomboswitch(b){
    state.beatcomboshow = button_switch2(state.beatcomboshow,b,"N","N")
    chart_refresh(beat)
}

function bga_switch(b){
    state.bga = button_switch2(state.bga,b,"A","A")
    if(state.bga){
        border.style.animation = "loading 15s linear infinite"
    }else{
        border.style.animation = "none"
    }
    chart_refresh(beat)
}

function fullscreen() {
    const el = document.documentElement;
    if (el.requestFullscreen) {
        el.requestFullscreen();
    }
}

videosizeslider.oninput = () => {
    video.style.height = videosizeslider.value + "vh"
}

audiosizeslider.oninput = () => {
    video.volume = audiosizeslider.value/100
}

mainbgheightslider.oninput = () => {
    rectbody.style.bottom = mainbgheightslider.value + "vh"
}

charttype.onchange = function(){
    if(charttype.value == "M"){
        maimaidif.style.display = "flex"
        maimaidiftext.style.display = "flex"
    }else{
        maimaidif.style.display = "none"
        maimaidiftext.style.display = "none"
    }
}

if(charttype.value == "M"){
    maimaidif.style.display = "flex"
    maimaidiftext.style.display = "flex"
}

jumpto.oninput = () => {
    pagejump(jumpto.value-beat)
}

async function process(){
    const origincharturl = originchart.value
    const charttypetext = charttype.value
    const maimainum = maimaidif.value
    const bpmlisttext = JSON.parse(bpmlist.value)
    const chartoffsettext = chartoffset.value
    const chartlist = []

    localStorage.setItem("chartoffset", chartoffsettext)
    localStorage.setItem("origincharturl", origincharturl)
    localStorage.setItem("charttype", charttypetext)
    localStorage.setItem("bpmlist",JSON.stringify(bpmlisttext))
    localStorage.setItem("maimaidif",maimainum)
    
    if(!origincharturl){
        tip.innerHTML = "路径未输入"
        return
    }

    if(!bpmlisttext[1] || bpmlisttext[1].length != 4){
        console.log(bpmlisttext[1],bpmlisttext[1].length);
        tip.innerHTML = "BPM列表错误"
        return
    }

    chartlist.push(origincharturl)
    chartlist.push(charttypetext)
    chartlist.push(bpmlisttext)
    chartlist.push(chartoffsettext)
    chartlist.push(maimainum)
    chartlist.push(approximate_mode)
    
    await fetch('../chartlistfetch', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(chartlist)
    })

    await fetch('../process')
    chartload()
    tip.innerHTML = "已执行"
}