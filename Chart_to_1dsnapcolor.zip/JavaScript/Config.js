
beat = parseInt(localStorage.getItem("beat")) || 2

chart = localStorage.getItem("chart") || 0

audio_offset.value = localStorage.getItem("audio_offset") || 0
video_offset.value = localStorage.getItem("video_offset") || 0


const startx = -17.5
const notex = startx + 15
alpha_null = 0.2
note_opacity = 0.52
lengthx = 1200

chartlength = null
red_pos = 0
current_BPM = [0]
next_BPM = [0]
nx = startx
speed = 10
running = false
combonum = 0
BPM = 0
current_beats = ""
next_beats = ""
pos_rect = 0
len = 0
bsignal="4/4"
current_page = 1
NoteTextureFolder = "NoteTexture"
c = 1
chartname = localStorage.getItem("chartname") || "RE"
approximate_mode = localStorage.getItem("approximate") || 0

time_span = 1
prevtime = 0

let filename = localStorage.getItem("filename") || null
let notenum = 0,vnum = 0
const timelist =[]
const state ={
    dragshow:false,
    flickshow:true,
    beatcomboshow:false,
    flickstyle:1,
    paused:true,
    jubeat_window:true,
    setting_window:true,
    setting_window2:false,
    window_all:true,
    video:false,
    videodiaplsy:false,
    videoplay:false,
    audio_on:true,
    panelwindow:false,
    hotmode:false,
    bga:false,
    approximate:false,
            }
const aper = {width:70,y1:-800,y2:35,y3:280}

let mode = localStorage.getItem("mode") || "null"

