function chart_refresh(beat){
    pos.style.opacity = 0.6;
    nx = startx;
    pos.style.left = nx + "px";
    pos_rect = 0;
    red_pos = 0;
    current_beats = "";
    next_beats = "";
    readchart(beat);
    tip_info()
    if(!running){
        combo.innerText=0;
        combonum = 0;
    }else{
        videosync()
    }
}

function pagejump(part){
    if(beat + part < 1){
        tip.innerHTML = "超出最低限制，不可翻页！";
    }else if(beat + part > chartlength){
        tip.innerHTML = "超出最高限制，不可翻页！";
    }else{
        beat += part
        chart_refresh(beat)
    }
}

function part_time_span(v){
    const len = v["length"]
    let time_length = 0

    for(i = 0;i < len; i++ ){
        if(len - i > 1){
            time_length += 1/v["BPM"][i]*60
        }else{
            time_length += (len-i)/v["BPM"][i]*60
        }
    }
    return time_length
}

function tip_info(){
    if(running){
        tip.innerHTML = `正在播放：${chartname}`
    }else{
        tip.innerHTML = `已选择文件：${chartname}`
    }
}
