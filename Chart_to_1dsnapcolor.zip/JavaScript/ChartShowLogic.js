function new_current_beat(time,values){
    let [src,count,id,text_alpha,text,noteindex,notecolor,notenum] = coloring(values,time);
    if(!src)return 0

    if(state.beatcomboshow){beatcomboopacity = 1}else{beatcomboopacity = 0}
    beattext = `
    <svg class = "svg" >

        <rect x="${150*time/12+notex+13}" y="10" width="44" height="44" fill="none" 
        stroke="#ffffff" stroke-width="0" rx="5" opacity = "0" style="filter: blur(1px);animation: fadeIn 0.15s ease forwards;--y:${aper.y3}px;--tx:${150*time/12+notex+35}px;--ty:${aper.y2}px;--fy:${aper.y1}px"/>

        <image id="${id}" href="${src}" opacity="${opacity}" noteindex="${noteindex}" notecolor="${notecolor}" notenum="${notenum}" count="${count}"
        x="${150*time/12+notex}" y="-2px" width="${aper.width}" style="filter: drop-shadow(3px 3px 2px rgba(0,0,0,0.8)) brightness(0.7);animation: fadeIn 0.15s ease forwards;--y:${aper.y3}px;--tx:${150*time/12+notex+35}px;--ty:${aper.y2}px;--fy:${aper.y1}px;--cy:${36}px"></image>

        <text x="${150*time/12+notex+35}px" y="12px" opacity="${text_alpha}"
        text-anchor="middle" font-size="10" font-weight="bold" fill="white" style="animation: fadeIn 0.15s ease forwards;--y:${aper.y3}px;--tx:${150*time/12+notex+35}px;--ty:${aper.y2}px;--fy:${aper.y1}px">${text}</text>
        
        <text x="${150*time/12+notex+35}px" y="65px" opacity="${beatcomboopacity}" 
        text-anchor="middle" font-size="16" font-weight="bold" fill="white" style="filter: drop-shadow(2px 2px 1px rgba(0,0,0,0.8));animation: fadeIn 0.15s ease forwards;--y:${aper.y3}px;--tx:${150*time/12+notex+35}px;--ty:${aper.y2}px;--fy:${aper.y1}px">${notenum}</text>
    
    </svg>` 
    current_beats = beattext + current_beats
}

function new_next_beat(time,next){
    let [src,count,id,text_alpha,text,noteindex,notecolor,notenum] = coloring(next,time)
    if(!src)return 0

    next_src = "NoteTexture/red_light.png"
    next_beats += `
    <svg class = "svg">
        <image href="${src}" id="${id}" noteindex="${noteindex}" notecolor="${notecolor}" notenum="${notenum}" count="${count}"
        x="${150*time/12+7.5}" y="55px" width="50px" opacity="${opacity}"
        style="animation: fadeIn2 0.2s ease forwards;--y:120px;--tx:${150*time/12+notex+35}px;--ty:-5px;--fy:0px"
        ></image>
    </svg>`;
    if(time == 0){
        if(opacity != 0){opacity = 0.3}
        //next_red
        current_beats += `<svg class = "svg">
        <image id="n" href="${src}" opacity="${opacity}" noteindex="${noteindex}" notecolor="${notecolor}" notenum="${notenum}" count="${count}"
        x="${300*len+notex}" y="-2px" width="${aper.width}" style="filter: drop-shadow(3px 3px 2px rgba(0,0,0,0.8)) brightness(0.7);
        animation: fadeIn 0.15s ease forwards;--y:${aper.y3}px;--tx:${300*len+notex+35}px;--ty:35px;--fy:0px;--cy:${36}px"></image>`;
    }
}

function coloring(part,time){
    let text_alpha = 0,count = 0,
        id = null,
        notecolor = null,
        noteindex = null
    
    const text = part["text"][part["time"].indexOf(time)],
        type = part["type"][part["time"].indexOf(time)],
        color_c = {red:[24,0],blue:[24,12],yellow:[12,6],green:[6,3],violet:[8,0],pink:[4,0]}
    
    count = part["count"][part["time"].indexOf(time)]
    notenum += 1

    if("index" in part){
        noteindex = part["index"][part["time"].indexOf(time)];
    }else{
        noteindex = 0
    }

    opacity = 0.52
    src = ""

    function color(){
        for(c in color_c){
            notecolor = c
            if((time+color_c[c][1])%color_c[c][0] == 0){
                return true
            }
        }
        notecolor = null
        return false
    }

    function texture(){
        if(buttonstate.flickstyle == 1 && type == 4){
            return `${NoteTextureFolder}/${c}_nf.png`
        }else{
            return `${NoteTextureFolder}/${c}_f.png`
        }
    }
    //tap
    function type_1(){
        opacity = 0.52
        text_alpha = 0
        if(color()){
            if(count == 1){src = `${NoteTextureFolder}/${c}_light.png`}
            else{src = `${NoteTextureFolder}/${c}_m.png`}
        }else{
            text_alpha = 1
            if(count == 1){src = `${NoteTextureFolder}/unkown_empty.png`}
            else{src = `${NoteTextureFolder}/unkown_m.png`}
        }   
    }
    //drag
    function type_2(){
        opacity = 0.51
        if(color(time)){
            src = `${NoteTextureFolder}/d${c}.png`
        }else{
            text_alpha = 1
            src = `${NoteTextureFolder}/dunkown_empty.png`
        }   
    }
    //flick
    function type_3(){
        opacity = 0.52
        if(color(time)){
            if(count == 1){src = `${NoteTextureFolder}/${c}_f.png`}
            else{src = `${NoteTextureFolder}/${c}_mf.png`}
        }else{
            text_alpha = 1
            if(count == 1){src = `${NoteTextureFolder}/unkown_f.png`}
            else{src = `${NoteTextureFolder}/unkown_mf.png`}
        } 
        id = "f"
    }

    if(type == 1 || type == 3)type_1()
    else if(type == 4 && state.flickshow){type_3()}
    else if(type == 4 && !state.flickshow){type_1()}
    else if(type == 2 && state.dragshow)type_2()
    else{
        src = false
        return [src,count,text_alpha,text,noteindex,notecolor,notenum]
    }

    //调试
    if(false){
        text_alpha = 0
        console.log(type,time);
    }
    return [src,count,id,text_alpha,text,noteindex,notecolor,notenum]
}

function basic_info_update(v,next,part){
    len = v["length"]
    current_BPM = v["BPM"]
    next_BPM = next["BPM"]
    page.innerText = part
    current_page = part
    BPM = v["BPM"][0]
    lengthx = 1200*len/4+startx
    time_span = part_time_span(v)

    if("sign" in v){
        bsignal = v["sign"]
    }
    const clength = 300*len,nlength = 300*next["length"],scale = 1325/(Math.max(clength,nlength,1200)+125)
    
    cbg.style.width = clength + "px"
    rectbody.style.setProperty("--s", `${scale}`);
    rectbody.style.left = 60
    document.getElementById("bs").innerText = `${bsignal.split('/')[0]}\n${bsignal.split('/')[1]}`

    bodybg.style.width = Math.max(clength,nlength,1200) + 60 + "px"
    star_movement(nlength)
    BPM_refresh()
}
 
function readchart(part){
    if(true){
        console.log("当前小节",part,"总小节数",chartlength)
    }

    if(part == NaN){
        tip.innerHTML = "小节序号（beat）错误,请刷新页面"
        localStorage.setItem("beat",1);
        return 
    }else if(part < 1){
        part = 1
    }

    if(!chart){
        tip.innerHTML = "谱面信息错误"
        localStorage.setItem("beat",1);
        return 
    }

    if(part == chartlength){
        document.getElementById("current_beats").innerHTML = "";
        running = false;
        tip.innerHTML = "播放结束，请向前滚动或回到起始位置"
        return
    }

    localStorage.setItem("beat",part);
    
    let v = chart[`${part}`]
    let next = chart[`${part+1}`]

    basic_info_update(v,next,part)

    notenum = 0
    for(let time of v["time"]){
        new_current_beat(time,v)
        vnum += 1
    }
    //beat_border
    let rbeat = ""
    document.getElementById("rbeat").innerHTML = rbeat
    
    //beat_bg
    let num = len/8 * 8
    
    for(i=0;i < num;i++){
        rbeat = `<div style ="
        position:absolute;border-radius: 10px;width: 36px;height: 36px;background:#444444;
        left: ${300*i+notex+18}px;top:15.5px;opacity: 0.5;box-shadow: 
        inset 2px 2px 4px rgba(0,0,0,0.3),
        inset -2px -2px 4px rgba(255,255,255,0.1);
        "></div>
        `+rbeat
        next_beats += `<div style ="
        position:absolute;border-radius: 10px;width: 24px;height: 6px;background:#222222;
        left: ${300*i+notex+24}px;top:56px;opacity: 0;box-shadow: 
        inset 1px 1px 4px rgba(0,0,0,0.3),
        inset -1px -1px 4px rgba(255,255,255,0.1);
        "></div>
        `
    }
    document.getElementById("rbeat").innerHTML = rbeat
    //next time
    notenum = 0
    for(let time of next["time"]){new_next_beat(time,next)}
    
    document.getElementById('current_beats').innerHTML = current_beats;
    document.getElementById('next_beats').innerHTML = next_beats;
}

function BPM_refresh(){
    const redbeat_div = document.getElementById("rbeat")
    const redbeat_style = redbeat_div.querySelectorAll("div")
    
    for(let style of redbeat_style){
        const redbeat_left = getComputedStyle(style).left
        red_x = parseFloat(redbeat_left)
        if(nx > red_x && red_x > red_pos){
            red_pos = red_x
            speed = current_BPM[parseInt(red_pos/300)]/33
            BPM = current_BPM[parseInt(red_pos/300)]
        } 
    }
    if(bpmtext.innerText != BPM){
        bpmtext.innerText = BPM;
        bpmbg.style.transition = "none";
        bpmbg.style.background = "#808080";
        void bpmbg.offsetWidth;
        bpmbg.style.transition = "background 0.2s ease";
        bpmbg.style.background = "#ffffff"; 
    }
    if(combo.innerText != combonum){
        combo.innerText=combonum;
        combobg.style.transition = "none";
        combobg.style.opacity = 0.3;
        void combobg.offsetWidth;
        combobg.style.transition = "opacity 0.4s ease";
        combobg.style.opacity = 0; 
    }
}

function notehit_effect(note){
    note.setAttribute("opacity","1");
    note.setAttribute("fill","#000000"); 
    note.style.filter = "drop-shadow(3px 3px 2px rgba(0,0,0,0.8)) brightness(1)"
    
    let note_x = parseFloat(note.getAttribute("x"));
    note.animate([{ transform: `scale(1) `,transformOrigin:`${note_x+30}px 80px`,offset:0,easing: "ease-out",},
                    { transform: `translateY(-2px) scale(1.1)`,offset:0.1,easing: "ease-out",},
                    { transform: "scale(1)",offset:1,easing: " ease-in",}], 
                {duration: 200,fill: "forwards"});
}

function position_to_offset(note,BPMlist){
    x = (parseFloat(note.getAttribute("x"))-7.5)/300
    let hit_delay = 0
    for(i = 0;i < x; i++ ){
        hit_delay = 1/BPMlist[i]*60*x
    }
    return hit_delay
}

function next_page(){
    nx = startx+15
    pos_rect = 0
    red_pos = 0

    //note播放打击音效
    if(state.audio_on){
        let next_notes = document.querySelectorAll("#next_beats image");
        for(let next of next_notes){
            id = next.getAttribute("id") 
            count = parseInt(next.getAttribute("count"))
            hit_delay = position_to_offset(next,next_BPM)
            if(id == "f"){count = 1.2}
            if((next.getAttribute("opacity") == 0.51)){
                dragsoundplay(hit_delay)
            }else{
                hitsoundplay(count,hit_delay)
            }
        }
    }
    
    
    current_beats = "";
    next_beats = "";
    beats_tempbg.innerHTML = document.getElementById('current_beats').innerHTML;

    //note退出动画
    const tnotes = document.querySelectorAll("#beats_tempbg image, #beats_tempbg rect, #beats_tempbg text");
    for(let note of tnotes){
        note.style.removeProperty("animation");
        note.classList.add("fadeoutanimation");
        if(note.tagName == "rect"){
            note.setAttribute("opacity",0)
        }
    }
    beat += 1;
    readchart(beat);

    //jubeat
    next_notes = document.querySelectorAll("#next_beats image");
    for(let next of next_notes){
        hit_delay = position_to_offset(next,next_BPM)
        let index = next.getAttribute("noteindex").split(",").map(String);  
        if(index != null && cs.innerHTML != ""){
            setTimeout(() => {
                Jubeatplay(next,index)
            },hit_delay*1000+800);    
        }
    }

    //note打击动画/combo刷新
    notes = document.querySelectorAll("#current_beats image");
    for(let note of notes){  
        id = note.getAttribute("id")
        hit_delay = position_to_offset(note,current_BPM)
        if(id == "n")continue
        setTimeout(() => {
            notehit_effect(note)
            count = note.getAttribute("count")
            pos.style.left = parseFloat(note.getAttribute("x")) + "px"
            nx = parseFloat(note.getAttribute("x"))
            combonum += parseInt(count)
        },hit_delay*1000);  
    }
}

function start(){
    pos.style.left = (((Date.now() - prevtime)/1000)/time_span)*lengthx + "px"
    BPM_refresh()

    if((Date.now() - prevtime)/1000 > time_span){
        prevtime += time_span*1000
        next_page()
    }
    
    if(running){requestAnimationFrame(start)}
}

function pos_refresh(note){
    if(note.tagName == "rect" && note.getAttribute("x") < pos_rect){
        note.setAttribute("opacity","0");
    }else
    if(note.tagName == "rect" && (note.getAttribute("x")-2 < nx)){
        note.setAttribute("opacity","1");
        pos_rect = note.getAttribute("x")-2
    }
}
function Jubeatplay(note,index){
    let notecolor = note.getAttribute("notecolor");
    notenum = note.getAttribute("notenum")
    for(let i of index){
        let hold = false
        if(i.includes("f")){
            t = i.split("f")[1]
            i = i.split("f")[0]
            hold = true
        }
        const 
        notecolors={red:"#FF6666",blue:"#66B2FF",yellow:"#FFD700",green:"#A9D146",violet:"#B266FF",pink:"#FF66B2",clan:"#33FF99",null:"#5c5c5c"}
        nc = notecolors[notecolor],
        note = document.getElementById(`note${i}`);
        note.style.setProperty("--notecolor",nc)
        note.style.color = "rgba(255, 255, 255, 1)";
        note.innerText = notenum;
        note.style.animation = "";
        void note.offsetWidth;
        note.style.animation = "notefade 0.5s ease-in forwards"; 

        if(hold){
            let holdnote = note
            holdnote.style.outline = "10px solid #ffffff"
            holdnote.style.outlineOffset = "-5px"
            setTimeout(() => {
                holdnote.style.outline = ""
                holdnote.style.animation = `holdfade ${t/BPM*60}s ease-in forwards`;
            }, 450);
        }
    }
}
function star_movement(next_length){
    if(star.style.left < next_length + 13 + "px"){
        star.style.animation = ""
        void star.offsetWidth
        star.style.animation = "rotatel 0.5s ease-out forwards"
        star.style.opacity = 0.1
        star.style.left = next_length + 13 + "px"
    }else if(star.style.left > next_length + 13 + "px"){
        star.style.animation = ""
        void star.offsetWidth
        star.style.animation = "rotatel 0.5s ease-out forwards"
        star.style.opacity = 0.1
        star.style.left = next_length + 13 + "px"
    }
}