from flask import Flask,send_from_directory,request
import webbrowser
from PyCharts import state

cp = Flask(__name__)

@cp.route('/')
def main():
    return send_from_directory('.','chartplay.html')

@cp.route('/<path:filename>')
def files(filename):
    return send_from_directory('.', filename)

@cp.route('/process')
def process():
    from PyCharts.chartprocess import main_function
    main_function()
    return "1"

@cp.route('/chartlistfetch', methods=['POST'])
def fixlistfetch():
    print(request.get_json())
    state.apr = request.get_json()[5]
    state.maiamidif = request.get_json()[4]
    state.chartoffset = request.get_json()[3]
    state.fixlist = request.get_json()[2]
    state.charttype = request.get_json()[1]
    state.origincharturl = request.get_json()[0]
    return "1"

if __name__ == '__main__':
    webbrowser.open('http://localhost:3000')
    cp.run(debug=False,port=3000)

    