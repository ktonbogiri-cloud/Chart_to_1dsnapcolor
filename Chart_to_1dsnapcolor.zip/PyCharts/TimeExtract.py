from fractions import Fraction
import json
import re

def chart_info(charttype,foldername,chartname,MAIMAI_difficulty = 3):
    chartoutput = f"outputcharts/{foldername}{chartname}.json"

    if charttype == "M":
        chartinput = f"charts/{foldername}/{chartname}.txt"
        orginalchart = ""
        end = "E"
        firsttext = f"&lv_{MAIMAI_difficulty}"
        collect = False

        with open(chartinput, "r", encoding="utf-8") as f:
            for line in f:

                if (not collect) and (firsttext in line):
                    collect = True
                        
                elif collect:
                    
                    if "des" in line:
                        continue

                    if "inote" in line:
                        orginalchart = re.search(r"\)(.*)",line).group(1)
                        orginalchart += "\n"
                        continue

                    if end == line[0] and not line[1].isdigit():
                        collect = False
                        break

                    print(end == line[0],line)
                    orginalchart += line

        chart_json = orginalchart

    else:
        chartinput = f"charts/{foldername}/{chartname}.json"
        with open(chartoutput, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=4)
        with open(chartinput, "r", encoding="utf-8") as f:
            chart_json = json.load(f)

    return chart_json,chartoutput

def phigrosoffcialchart(chart_json,chartoffset):
    #提取时间列表
    timelist=[]
    for jl in chart_json["judgeLineList"]:
        for notes in jl["notesAbove"]:
            note = {}
            note["time"] = Fraction(notes["time"]*4,128)+chartoffset
            note["type"] = notes["type"]
            timelist.append(note)
        for notes in jl["notesBelow"]:
            note = {}
            note["time"] = Fraction(notes["time"]*4,128)+chartoffset
            note["type"] = notes["type"]
            timelist.append(note)
    #按时间排序
    timelist.sort(key=lambda t:t["time"])
    return timelist

def phira(chart_json,chartoffset):
    timelist=[]
    for jl in chart_json["judgeLineList"]:
        if "notes" in jl:
            for note in jl["notes"]:
                if note["isFake"] == 0:
                    timearray = note["startTime"]
                    note["time"] = timearray[0]+Fraction(timearray[1],timearray[2]).limit_denominator(128)+chartoffset
                    if note["type"] == 3:
                        note["type"] = 4
                    elif note["type"] == 4:
                        note["type"] = 2
                    elif note["type"] == 2:
                        note["type"] = 3
                    elif note["type"] == 1:
                        note["type"] = 1
                    timelist.append(note)

    timelist.sort(key=lambda t:t["time"])
    return timelist

def jubeat_malody(chart_json,chartoffset):
     #提取时间列表，一拍为1
    timelist=[]
    for notes in chart_json["note"]:
        note = {}
        if "index" in notes:
            note["index"] = notes["index"]
        else:
            continue
        if "endbeat" in notes:
            note["index"] = str(notes["index"]) +"f"+ str((notes["endbeat"][0]-notes["beat"][0])+(notes["endbeat"][1]/notes["endbeat"][2])-(notes["beat"][1]/notes["beat"][2]))
        if notes["beat"][2] == 48:
            notes["beat"][1] += 1
        note["time"] = notes["beat"][0]+Fraction(notes["beat"][1],notes["beat"][2])+chartoffset
        note["type"] = 1
        
        if "endbeat" in notes:
            note["type"] = 4
        timelist.append(note)
    #按时间排序
    timelist.sort(key=lambda t:t["time"])
    # del timelist[0]
    return timelist

def mm_read(chart_json,chartoffset):
    note = {}
    time = chartoffset*24
    timelist = []
    note_span = 0
    touchlist = ["A", "B", "C", "E", "F"]

    def time_read(notes_data):
        nonlocal time,note,note_span
        def type_check(note_data):
            if "h" in note_data:
                notetype = 3
            elif "-" in note_data:
                notetype = 4   
            elif set(touchlist) & set(note_data):
                notetype = 1
            elif "b" in note_data:
                notetype = 1
            elif "x" in note_data:
                notetype = 1
            else:
                notetype = 1
            return notetype

        def time_input(note_data,time):
            note = {}
            def note_input():
                note["time"] = Fraction(int(time),24)
                note["type"] = type_check(note_data)
                timelist.append(note)

            if "/" in note_data:
                note_array = note_data.split("/")
                for note_data in note_array:
                    note_input()
            else:
                note_input()

        for note_data in notes_data:
            if note_data == "":
                time += note_span
                continue

            elif "{" in note_data:
                sign = int(note_data.split("}")[0].split("{")[-1])
                note_span = 96/sign
                note_data = note_data.split("}")[-1]

                if note_data == "":
                    time += note_span
                    continue

            time_input(note_data,time)
            time += note_span

    for line in chart_json.splitlines():

        if "E" in line and len(line) == 1:
            break

        notes_data = line.split(",")
        del notes_data[-1]

        time_read(notes_data)

    timelist.sort(key=lambda t:t["time"])
    return timelist