from fractions import Fraction

def fixtime(time):
    bt = time % 1
    if bt == Fraction(5,16):
        rt = Fraction(1,3)+time//1
    elif bt == Fraction(11,32):
        rt = Fraction(1,3)+time//1
    elif bt == Fraction(21,32):
        rt = Fraction(2,3)+time//1
    elif bt == Fraction(27,32):
            rt = Fraction(5,6)+time//1
    elif bt == Fraction(5,32):
        rt = Fraction(1,6)+time//1
    elif bt == Fraction(13,16):
        rt = Fraction(5,6)+time//1
    else:
        rt = time
    return rt

def initfixchart(charttype,chartlength):
    fixchart = {}
    for v in range(1,chartlength):
        fixchart[v] = {}
        fixchart[v]["time"] = []
        fixchart[v]["text"] = []
        fixchart[v]["type"] = []
        if charttype == "J":
            fixchart[v]["index"] = []
        fixchart[v]["count"] = []
    return fixchart

#修正时间列表，统计时间出现次数,计算时值信息
def fix_time(timelist):
    fixtimelist = []
    i = {};sc = 0#时值指针

    for note in timelist:
        i["time"] = note["time"]
        if "index" in note:
            i["index"] = []
        i["count"] = 0
        i["type"] = note["type"]
        i["time_span"] = note["time"]-sc
        sc = note["time"]

        if fixtimelist == [] or note["time"] != fixtimelist[-1]["time"]:#新note
            if note["type"] != 2:
                i["count"] += 1
                if "index" in note:
                    i["index"].append(note["index"])
            fixtimelist.append(i)
            i = {}
        elif note["time"] == fixtimelist[-1]["time"] and note["type"] != 2:#重复note
            #优先级展示
            if note["type"] == 4:
                fixtimelist[-1]["type"] = 4
            elif note["type"] == 3 and fixtimelist[-1]["type"] != 4:
                fixtimelist[-1]["type"] = 3
            elif note["type"] == 1 and fixtimelist[-1]["type"] != 4:
                fixtimelist[-1]["type"] = 1
            fixtimelist[-1]["count"] += 1
            if "index" in note:
                fixtimelist[-1]["index"].append(note["index"])

    #时值错位纠正
    for i in range(len(fixtimelist)):
        if i == len(fixtimelist)-1:
            fixtimelist[i]["time_span"] = 0
        else:
            fixtimelist[i]["time_span"] = fixtimelist[i+1]["time_span"]

    return fixtimelist

def timesplit(fixchart,start_time,timelist,fix_list,apr,gap,propotion):

    beat_scale = (start_time-1)*gap#初始节拍刻度
    beatlist = []
    countlist = []
    realtimelist = []
    typelist = []
    textlist = []
    indexlist=[]

    def columnclear():
        nonlocal beatlist,realtimelist,countlist,textlist,typelist,indexlist
        beatlist = []
        realtimelist= []
        countlist= []
        textlist= []
        typelist= []
        indexlist= []

    def columninput(real_gap=4):
        nonlocal beat_scale,start_time
        fixchart[start_time]["time"] = beatlist
        fixchart[start_time]["realtime"] = realtimelist
        fixchart[start_time]["text"] = textlist
        fixchart[start_time]["count"] = countlist
        fixchart[start_time]["type"] = typelist
        if "index" in v:
            fixchart[start_time]["index"] = indexlist
        columnclear()
        #计算跨度值，赋值新的片段
        beat_scale += real_gap
        start_time += 1

    def datainput(part_span,propotion):
        nonlocal beatlist,realtimelist,countlist,textlist,typelist,indexlist
        if apr == 1:
            ft = float(Fraction((part_span*24)*propotion).limit_denominator(8))
        else:
            ft = float((part_span*24)*propotion)
        text = str(Fraction(part_span)%1)
        beatlist.append(ft)
        realtimelist.append(str(real_time//1)+"+"+str(real_time%1))
        countlist.append(v["count"])
        typelist.append(v["type"])
        textlist.append(text)
        if "index" in v:
            indexlist.append(v["index"])

    i = 0
    while i < len(timelist):

        v = timelist[i]
        real_time = Fraction(v["time"])
        # print(real_time,start_time,beat_scale,end="|")

        if Fraction(real_time) >= beat_scale:
            if start_time + 1 in fix_list:
                gap = fix_list[start_time + 1][2]
                propotion = fix_list[start_time + 1][1] / fix_list[start_time + 1][2]
            columninput(gap)
            columnclear()
        else:
            part_span = real_time + gap - beat_scale
            if apr == 1 :
                datainput(fixtime(part_span),propotion)
            else:
                datainput(part_span,propotion)
            i+=1

    #补充未计入的片段
    if beatlist != []:
        columninput(gap)

    #长度
    #一拍为24，32分为3，24分为4，
    #黄色为6+12n，红与紫色为8n，蓝色为12+24n，红为24n
    for beat in fixchart:
        if beat in fix_list:
            l = fix_list[beat][1]
            b = fix_list[beat][0]
            s = fix_list[beat][3]
        fixchart[beat]["length"] = l
        fixchart[beat]["BPM"] = [b]*int(l+0.99)
        fixchart[beat]["sign"] = s

def final_fix(fixtimelist,fixchart,chartlength):
    #修正时间文本可读性
    for i in fixtimelist:
        i["time"] = str(i["time"]//1)+"+"+str(i["time"]%1)
        i["time_span"] = str(i["time_span"])

    #删除尾部空拍
    for beat in reversed(fixchart):
        if fixchart[beat]["time"] != []:
            for i in range(beat+4,chartlength):
                del fixchart[i]
            break
