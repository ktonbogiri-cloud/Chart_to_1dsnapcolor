fixlist = {}
charttype = ""
origincharturl = ""
chartoffset = 0
maiamidif = 1
apr = 0