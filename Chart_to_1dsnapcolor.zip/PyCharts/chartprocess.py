import json
from PyCharts.TimeExtract import phira,phigrosoffcialchart,jubeat_malody,mm_read,chart_info
from PyCharts.functions import initfixchart,fix_time,timesplit,final_fix
from PyCharts import state

def main_function():
    chartlength = 900
    start = 1

    apr = int(state.apr)
    charttype = state.charttype
    chartoffset = float(state.chartoffset)

    maimaidif = int(state.maiamidif)

    fixlist = state.fixlist
    fixlist = {int(k): v for k, v in fixlist.items()}

    propotion = fixlist[1][1] / fixlist[1][2]
    gap = fixlist[1][2]

    charturllist = state.origincharturl.split("/")

    foldername = ""
    if len(charturllist) > 1:
        foldername = charturllist[-2]
    chartname = charturllist[-1]

    chart_json,chartoutput = chart_info(charttype,foldername,chartname,maimaidif)

    if charttype == 'P':
        timelist = phigrosoffcialchart(chart_json,chartoffset)
    elif charttype == 'J':
        timelist = jubeat_malody(chart_json,chartoffset)
    elif charttype == 'R':
        timelist = phira(chart_json,chartoffset)
    elif charttype == "M":
        timelist = mm_read(chart_json,chartoffset)

    fixchart = initfixchart(charttype,chartlength)

    fixtimelist = fix_time(timelist)
    print("初始化时间列表")

    timesplit(fixchart,start,fixtimelist,fixlist,apr,gap,propotion)
    print("时间切割")

    final_fix(fixtimelist,fixchart,chartlength)
    print("修正")

    with open("fixtimelist.json", "w", encoding="utf-8") as f:
        json.dump(fixtimelist, f, indent=4)
    print("保存信息至修正时间列表")

    with open("fixchart.json", "w", encoding="utf-8") as f:
        json.dump(fixchart, f, indent=4)
    print("保存信息至修正谱面")

    with open(chartoutput, "w", encoding="utf-8") as f:
        json.dump(fixchart, f, indent=4)
    print("输出修正谱面")

    print("执行成功")
