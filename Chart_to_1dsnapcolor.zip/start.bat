@echo off
python "%~dp0Start.py"
pause